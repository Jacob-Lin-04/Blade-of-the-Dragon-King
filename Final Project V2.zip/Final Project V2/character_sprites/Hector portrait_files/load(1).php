.main-tooltip{border:1px solid #cac4b5;box-shadow:2px 2px 5px rgba(0,0,0,0.3);margin-bottom:5px;padding:2px 5px;background-color:#fbeecb} #tooltip-wrapper{padding:3px 7px 2px 3px} .has-redlinks,.tooltip-loading,.advanced-tooltip .tooltip-contents{display:none}.tooltips-init-complete{cursor:help}

/* cache key: fireemblem:resourceloader:filter:minify-css:7:465b0de070abd3d9e093de6593f6b564 */