# Jacob Lin
# December 16, 2019
# Blade of the Dragon King Character Class

import pygame
import random

pygame.init()

class dragon_king():
    enemys = {}
    tile_size = 50
    def __init__(self,portrait_path,sprite_path,dragon_x,dragon_y,d_HP,d_HP_cap,d_name):
        self.dragon_x = dragon_x
        self.dragon_y = dragon_y
        self.d_name = d_name
        self.d_HP = d_HP
        self.d_HP_cap = d_HP_cap
        self.portrait = pygame.transform.scale(pygame.image.load(portrait_path).convert_alpha(), (100,100))
        self.sprite = pygame.image.load(sprite_path).convert_alpha()
        dragon_king.enemys[d_name] = self

class character():
    players = {}
    attacks = {}
    tile_size = 50
    def __init__(self, portrait_path, sprite_path, x, y, character_class,HP,HP_cap,STR,SPD,DEX, name, move1, move2):
        self.x = x
        self.y = y
        self.name = name
        self.character_class = character_class
        self.portrait = pygame.image.load(portrait_path).convert_alpha()
        self.HP = HP
        self.HP_cap = HP_cap
        self.STR = STR
        self.SPD = SPD
        self.DEX = DEX
        self.sprite = pygame.transform.scale(pygame.image.load(sprite_path).convert_alpha(), (50, 50))
        self.move1 = move1
        self.move2 = move2
        character.players[name] = self
        character.attacks[move1] = move1
        character.attacks[move2] = move2
    def move_up(self):
        if self.check_valid(self.x, self.y - character.tile_size):
            self.y -= character.tile_size
        else:
            print("Invalid move!")
    def move_down(self):
        if self.check_valid(self.x, self.y + character.tile_size):
            self.y += character.tile_size
        else:
            print("Invalid move!")
    def move_right(self):
        if self.check_valid(self.x + character.tile_size, self.y):
            self.x += character.tile_size
        else:
            print("Invalid move!")
    def move_left(self):
        if self.check_valid(self.x - character.tile_size, self.y):
            self.x -= character.tile_size
        else:
            print("Invalid move!")
    def check_valid(self, x, y):
        for player in character.players:
            checked_player = character.players[player]
            
            if player != self.name:
                if x == checked_player.x and y == checked_player.y:
                    return False
                elif x > 850 or x < 0 or y < 0 or y > 650:
                    return False
        for enemy in dragon_king.enemys:
            checked_enemy = dragon_king.enemys[enemy]
            if x >= checked_enemy.dragon_x and x <= checked_enemy.dragon_x + 300 and y >= checked_enemy.dragon_y and y <= checked_enemy.dragon_y + 50 :
                return False
        return True
    #def player_attack(character_class,STR,SPD,DEX,RANGE):
    
    def player_attack(self,enemys):
        #class specific attacks
        global attack_dmg
        if self.character_class == "Lord":
            hit = random.randint(self.SPD,11)
            #def Blade_Slash(attack_dmg,hit,crit):
            if hit >= 6:
                crit = random.randint(DEX,21)
                if crit >= 15:
                    attack_dmg = 250
                else:
                    attack_dmg = randint((STR* 3),80)
            else:
                print("MISS")
                attack_dmg = 0 
        if self.character_class == "Journeyman":
            hit = random.randint(self.SPD,11)
    def attack_check_valid(self,x,y):
        global attack_range
        for enemy in dragon_king.enemys:
            checked_enemy = dragon_king.enemys[enemy]
            if x >= checked_enemy.dragon_x + attack_range and x <= checked_enemy.dragon_x + 300 + attack_range\
               and y >= checked_enemy.dragon_y - attack_range and y <= checked_enemy.dragon_y + attack_range:
                return True
            return False
        
    
