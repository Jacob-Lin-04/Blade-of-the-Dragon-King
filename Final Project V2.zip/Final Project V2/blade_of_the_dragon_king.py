# Jacob Lin
# December 16, 2019
# Blade of the Dragon King Map Sprites
import time
import random
import math
import pygame
from character_sheet import *

pygame.init()
size = (900, 900)
screen = pygame.display.set_mode(size)
done = False
clock = pygame.time.Clock()
pygame.mouse.set_visible(False)
#Colours
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLACK = (0, 0, 0)

#map image
background = pygame.transform.scale(pygame.image.load('Background sprites/mount guiji.png').convert_alpha(),(900,900))

#Menu Gui
font = pygame.font.SysFont("bahnschrift", 20, True, False)
title_font = pygame.font.SysFont("bahnschrift", 55, True, True)
menu_background = pygame.transform.scale(pygame.image.load('menu_sprites/sand_brick.png').convert_alpha(), (900, 300))
battle_text = pygame.transform.scale(pygame.image.load('menu_sprites/dialog_box.png').convert_alpha(), (900, 200))
cursor = pygame.transform.scale(pygame.image.load('menu_sprites/cursor.png').convert_alpha(),(25,75))
start_background = pygame.transform.scale(pygame.image.load('menu_sprites/Peach_Festival.jpg').convert_alpha(),(900,900))


#Characer Renders
Yu = character("character_sprites/portrait_roy.png", "character_sprites/roy_default.png", 400, 650, "Lord"\
          , 175, 175,7,8,8,"Yu","Blade Slash","Piercing Thrust")
Shun= character("character_sprites/portrait_hector.png", "character_sprites/hector_default.png", 450, 650, "Journeyman",\
          250,250,9,5,6,"Shun","Axe Bash","Charging Blow")
Lihua = character("character_sprites/portrait_rebecca.png", "character_sprites/rebecca_default.png", 500, 650, "Archer",\
          125,125,5,7,9,"Lihua","Zap Arrow", "Deadeye")
Meifeng = character("character_sprites/portrait_serra.png", "character_sprites/serra_default.png", 550, 650, "Cleric",\
          100,100,5,6,6, "Meifeng","Healing Wind", "Light Beam")
selected_player = character.players["Yu"]

#enemy renders
Dragon = dragon_king("character_sprites/Dragon head.png","character_sprites/DragonKing.png",250,100,1000,1000,"Sihai Longwang the Dragon God")
selected_enemy = dragon_king.enemys["Sihai Longwang the Dragon God"]

m_x = 0
m_y = 0
player_up = False
player_down = False
player_left = False
player_right = False
user_click = False 
screen_mode = "start"
p_attack = False
start_color = WHITE
attack_dmg = 0
attack_range = 50 


def draw_map(screen):
    screen.blit(background,(0,0))
    for y in range(15):
        for x in range(20):
            pygame.draw.rect(screen, BLACK, [x * 50, y * 50, 50, 50], 2)
    screen.blit(menu_background, (0, 700))
    screen.blit(battle_text, (0, 700))
    
def draw_menu(screen):
    global p_attack
    character_text = font.render("Name: {}    Class: {}".format(selected_player.name.upper(), selected_player.character_class.upper()), True, WHITE)
    stats_text = font.render("HP: {}/{} STR: {} SPD: {} DEX {}".format(selected_player.HP, selected_player.HP_cap, selected_player.STR, selected_player.SPD, selected_player.DEX), True, WHITE)
    enemy_name_text = font.render("{}".format(selected_enemy.d_name),True, WHITE)                            
    enemy_text = font.render("HP: {}/{} STR: 1000 SPD: 1000 DEX: 100".format(selected_enemy.d_HP,selected_enemy.d_HP_cap), True, WHITE)
    if p_attack == False:
        #Attack button
        attack_button = font.render("Attack",True,BLACK)
        if m_x >=530 and m_x <= 720 and m_y <= 770 and m_y > 710:
            pygame.draw.rect(screen,GREEN,[535,715,100,50])
            if user_click == True:
                p_attack = True
        else:
            pygame.draw.rect(screen,WHITE,[535,715,100,50])
        screen.blit(attack_button,(550,725))
    elif p_attack == True:
        selected_player.player_attack()
        attack_text = font.render(selected_player.name+" Did: "+str(attack_dmg)+" Damage",True,WHITE)
        screen.blit(attack_text,(600,800))
        pygame.display.update()
        character.player_attack(enemys)
        p_attack = False
    if m_x >= 300 and m_x <= 600 and m_y >=100 and m_y <= 200:
        screen.blit(enemy_name_text,(150,725))
        screen.blit(enemy_text,(150,750))
        screen.blit(selected_enemy.portrait,(50,725))
    else:
        
            
        screen.blit(selected_player.portrait, (50, 750))
        screen.blit(character_text, (150, 725))
        screen.blit(stats_text,(150,750))
        
        

    #Attack menu pop up:
    
    
        
def start_menu(screen):
    global screen_mode
    title_text = title_font.render("The Blade of the Dragon King",True,BLACK)
    start_menu = font.render("Start",True,BLACK)
    screen.blit(start_background,(0,0))
    screen.blit(title_text,(30,100))
    pygame.draw.rect(screen,WHITE,[380,390,100,50])
    screen.blit(start_menu,(400,400))
    if m_x <= 500 and m_x >= 300 and m_y >= 350 and m_y <= 450:
        pygame.draw.rect(screen,GREEN,[380,390,100,50])        
        screen.blit(start_menu,(400,400))
        if user_click == True:
            screen_mode = "battle"
           

    

#Game Loop
while not done:
    # event handling
    for event in pygame.event.get():
        #print(user_click, str(m_x) + ", " + str(m_y))
        #print(screen_mode)
        print(p_attack)
        if event.type == pygame.QUIT:
            done = True
        if event.type == pygame.MOUSEBUTTONDOWN:
            buttons = pygame.mouse.get_pressed()
            if buttons[0]:
                user_click = True 
        if event.type == pygame.MOUSEBUTTONUP:
            if not buttons[1]:
                user_click = False 
        if event.type == pygame.KEYDOWN:
            if event.key == 49:
                selected_player = character.players["Yu"]
                attack_range = 50
            elif event.key == 50:
                selected_player = character.players["Shun"]
                attack_range = 50
            elif event.key == 51:
                selected_player = character.players["Lihua"]
                attack_range
            elif event.key == 52:
                selected_player = character.players["Meifeng"]
            if event.key == pygame.K_w: 
                player_up = True
            if event.key == pygame.K_a:
                player_left = True 
            if event.key == pygame.K_s:
                player_down = True 
            if event.key == pygame.K_d:
                player_right = True
    #Cursor Blit
    pos = pygame.mouse.get_pos()
    m_x = pos[0] - 10
    m_y = pos[1] - 5
    
    if screen_mode == "start":
        start_menu(screen)
        screen.blit(cursor,(m_x,m_y))
        
    if screen_mode == "battle":
        if player_up:
            selected_player.move_up()
            player_up = False
        if player_down:
            selected_player.move_down()
            player_down = False
        if player_right:
            selected_player.move_right()
            player_right = False
        if player_left:
            selected_player.move_left()
            player_left = False
        screen.fill(WHITE)
        
        draw_map(screen)
        draw_menu(screen)
        
        for player in character.players:
            drawn_player = character.players[player]
            screen.blit(drawn_player.sprite, (drawn_player.x, drawn_player.y))
        for enemy in dragon_king.enemys:
            drawn_enemy = dragon_king.enemys[enemy]
            screen.blit(drawn_enemy.sprite, (drawn_enemy.dragon_x,drawn_enemy.dragon_y))
        #selected_player.HP -= 1
        
        screen.blit(cursor,(m_x,m_y))
         
    pygame.display.update()
    clock.tick_busy_loop(60)
pygame.quit()
